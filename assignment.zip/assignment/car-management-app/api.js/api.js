// src/api.js
import axios from 'axios';

// Base URL for the API (change to your backend URL if deployed)
const API_URL = 'http://localhost:5000/api/cars';

// Axios instance for API requests
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Register user
export const registerUser = async (email, password) => {
  try {
    const response = await axios.post('http://localhost:5000/api/users/register', { email, password });
    return response.data;
  } catch (error) {
    console.error('Error registering user', error);
    throw error;
  }
};

// Login user
export const loginUser = async (email, password) => {
  try {
    const response = await axios.post('http://localhost:5000/api/users/login', { email, password });
    return response.data; // Save the token here, e.g., in localStorage
  } catch (error) {
    console.error('Error logging in user', error);
    throw error;
  }
};

// Get list of products (cars)
export const getProducts = async (token) => {
  try {
    const response = await api.get('/', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching products', error);
    throw error;
  }
};

// Get a particular product by ID
export const getProductById = async (id, token) => {
  try {
    const response = await api.get(`/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching product', error);
    throw error;
  }
};

// Create a new product
export const createProduct = async (productData, token) => {
  try {
    const response = await api.post('/', productData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error creating product', error);
    throw error;
  }
};

// Update a product
export const updateProduct = async (id, productData, token) => {
  try {
    const response = await api.put(`/${id}`, productData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error updating product', error);
    throw error;
  }
};

// Delete a product
export const deleteProduct = async (id, token) => {
  try {
    const response = await api.delete(`/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error deleting product', error);
    throw error;
  }
};
