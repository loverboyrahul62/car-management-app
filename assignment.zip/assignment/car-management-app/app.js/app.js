import React, { useContext } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import { AuthContext } from './context/authContext'; // Import the AuthContext
import Home from './components/Home/Home';
import Login from './components/Login/Login';
import ProductList from './components/Product/ProductList';
import ProductDetail from './components/Product/ProductDetail';

function App() {
  const { user } = useContext(AuthContext); // Access the logged-in user from context

  return (
    <Router>
      <div>
        <h1>Car Management App</h1>
        
        {/* Add a basic navigation bar */}
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/products">Products</Link></li>
            {!user ? (
              <li><Link to="/login">Login</Link></li>
            ) : (
              <li><button onClick={() => { localStorage.removeItem('userToken'); window.location.href = '/'; }}>Logout</button></li>
            )}
          </ul>
        </nav>
        
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={user ? <Navigate to="/products" /> : <Login />} />  {/* Redirect if already logged in */}
          
          {/* Protected Routes (only accessible when logged in) */}
          <Route path="/products" element={user ? <ProductList /> : <Navigate to="/login" />} />
          <Route path="/product/:id" element={user ? <ProductDetail /> : <Navigate to="/login" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
