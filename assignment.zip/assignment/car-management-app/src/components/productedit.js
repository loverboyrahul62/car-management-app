// src/components/Product/ProductEdit.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';  // For fetching product ID and navigation
import { getProductById, updateProduct } from '../../api';  // Import the necessary API functions

function ProductEdit() {
  const { id } = useParams();  // Get product ID from URL params
  const navigate = useNavigate();
  
  const [product, setProduct] = useState({
    title: '',
    description: '',
    images: [],
    tags: []
  });
  const [error, setError] = useState('');

  // Fetch the product data when the component mounts
  useEffect(() => {
    const fetchProduct = async () => {
      const token = localStorage.getItem('token'); // Get the token for authentication
      if (!token) {
        setError('You are not logged in!');
        return;
      }
      
      try {
        const data = await getProductById(id, token);  // Fetch product details
        setProduct(data);  // Populate the state with product data
      } catch (error) {
        setError('Failed to fetch product details.');
      }
    };

    fetchProduct();
  }, [id]);  // Run effect when product ID changes

  // Handle form submission to update the product
  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) {
      setError('You are not logged in!');
      return;
    }

    try {
      await updateProduct(id, product, token);  // Call the updateProduct API function
      navigate(`/product/${id}`);  // Redirect to the product detail page after successful update
    } catch (err) {
      setError('Failed to update product.');
    }
  };

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct({ ...product, [name]: value });
  };

  // Handle image file changes
  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setProduct({ ...product, images: files });
  };

  return (
    <div>
      <h2>Edit Product</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Title</label>
        <input
          type="text"
          name="title"
          value={product.title}
          onChange={handleChange}
          required
        />
        
        <label>Description</label>
        <textarea
          name="description"
          value={product.description}
          onChange={handleChange}
          required
        />
        
        <label>Tags</label>
        <input
          type="text"
          name="tags"
          value={product.tags.join(', ')} // Display tags as a comma-separated list
          onChange={handleChange}
          placeholder="Enter tags separated by commas"
        />
        
        <label>Images</label>
        <input
          type="file"
          name="images"
          multiple
          onChange={handleImageChange} // Update the images array with selected files
        />
        
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
}

export default ProductEdit;
