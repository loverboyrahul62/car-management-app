
import React from 'react';

function ProductList({ cars }) {
  return (
    <div>
      <h2>Product List</h2>
      <ul>
        {cars.map((car) => (
          <li key={car._id}>{car.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default ProductList;
