
import React, { useEffect, useState } from 'react';
import { getAllCars } from '../../api'; // Assuming you have API functions in api.js

function Home() {
  const [cars, setCars] = useState([]);

  useEffect(() => {
    const fetchCars = async () => {
      const carsData = await getAllCars();
      setCars(carsData); // Update state with fetched cars
    };
    fetchCars();
  }, []);

  return (
    <div>
      <h2>All Cars</h2>
      <ul>
        {cars.map((car) => (
          <li key={car._id}>{car.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default Home;
